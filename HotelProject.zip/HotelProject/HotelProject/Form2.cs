﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HotelProject
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            switch (comboBoxTables.Text)
            {
                case "Categories":
                    this.categoriesTableAdapter.Fill(this.hotelDataSet1.Categories);
                    break;
                case "Rooms":
                    this.roomsTableAdapter.Fill(this.hotelDataSet1.Rooms);
                    break;
                case "Roles":
                    this.rolesTableAdapter.Fill(this.hotelDataSet1.Roles);
                    break;
                case "Users":
                    this.usersTableAdapter.Fill(this.hotelDataSet1.Users);
                    break;
                case "StatusRoom":
                    this.statusRoomTableAdapter.Fill(this.hotelDataSet1.StatusRoom);
                    break;
                case "StatusCleaning":
                    this.statusCleaningTableAdapter.Fill(this.hotelDataSet1.StatusCleaning);
                    break;
                case "RoomOccupancy":
                    this.roomOccupancyTableAdapter.Fill(this.hotelDataSet1.RoomOccupancy);
                    break;
                default:
                    this.categoriesTableAdapter = null;
                    this.roomsTableAdapter = null;
                    this.rolesTableAdapter = null;
                    this.usersTableAdapter = null;
                    this.statusRoomTableAdapter = null;
                    this.statusCleaningTableAdapter = null;
                    this.roomOccupancyTableAdapter = null;
                    break;
            }
            
        }

        private void categoriesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.categoriesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.hotelDataSet1);

        }
    }
}
